package com.shadow.apkanalyzer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var results: TextView
    private lateinit var exportJson: Button
    private lateinit var exportHtml: Button
    private val apps = mutableListOf<ApplicationInfo>()
    private var lastReport: AnalysisReport? = null

    private val openApk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            runAnalysis("تحليل الملف") { Analyzer.analyzeUri(this, uri, search.text.toString()) }
        }
    }
    private val saveJson = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> uri?.let { saveReport(it, false) } }
    private val saveHtml = registerForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri -> uri?.let { saveReport(it, true) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16,16,24)
        window.navigationBarColor = android.graphics.Color.rgb(16,16,24)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(20, 22, 20, 16)
            setBackgroundColor(0xFF101018.toInt())
        }
        val header = TextView(this).apply {
            text = "SHADOW APK ANALYZER PRO 2.1"
            textSize = 23f; setTextColor(0xFFC4B5FD.toInt()); typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        root.addView(label("منصة محلية لفحص ملفات التطبيقات وتحليل مؤشرات الأمان والشراء"))
        search = EditText(this).apply {
            hint = "كلمة أو دالة للبحث (اختياري)"; setHintTextColor(0xFF999999.toInt())
            setTextColor(-1); setSingleLine(); textSize = 15f
        }
        root.addView(search, matchWrap())
        addButton("اختيار ملف APK / APKS / XAPK") { openApk.launch(arrayOf("application/vnd.android.package-archive", "application/zip", "application/octet-stream", "*/*")) }
        addButton("عرض التطبيقات المثبتة القابلة للتحليل") { showInstalledApps() }
        val exportRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        exportJson = smallButton("تصدير JSON") { if (lastReport == null) toast("قم بإجراء تحليل أولاً") else saveJson.launch("shadow_report.json") }
        exportHtml = smallButton("تقرير HTML") { if (lastReport == null) toast("قم بإجراء تحليل أولاً") else saveHtml.launch("shadow_report.html") }
        exportRow.addView(exportJson, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = 6 })
        exportRow.addView(exportHtml, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = 6 })
        root.addView(exportRow)
        status = label("الحالة: جاهز للفحص")
        root.addView(status)
        val scroll = ScrollView(this)
        results = TextView(this).apply {
            text = "اختر ملف APK أو تطبيقاً مثبتاً لبدء الفحص.\n\nالمزايا: بصمة SHA-256، بيانات الحزمة، الأذونات الحساسة، مؤشرات الشراء، وسلاسل DEX النصية.\n\nيعمل التحليل محلياً ولا يرفع الملفات إلى أي خادم."
            textSize = 13f; setTextColor(0xFFE5E7EB.toInt()); setPadding(0, 12, 0, 12)
        }
        scroll.addView(results)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        setExportsEnabled(false)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 14f; setTextColor(0xFFE5E7EB.toInt()); setPadding(0, 10, 0, 10)
    }

    private fun addButton(text: String, action: () -> Unit) {
        val button = Button(this).apply {
            this.text = text; setTextColor(-1); setBackgroundColor(0xFF4C357A.toInt())
            setOnClickListener { action() }
        }
        root.addView(button, matchWrap())
    }

    private fun smallButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 12f; setTextColor(-1); setBackgroundColor(0xFF302747.toInt())
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 7 }

    private fun setExportsEnabled(enabled: Boolean) { exportJson.isEnabled = enabled; exportHtml.isEnabled = enabled; exportJson.alpha = if (enabled) 1f else .45f; exportHtml.alpha = if (enabled) 1f else .45f }

    private fun showInstalledApps() {
        apps.clear(); apps.addAll(Analyzer.installedLaunchableApps(this))
        if (apps.isEmpty()) { status.text = "لم يتم العثور على تطبيقات قابلة للتشغيل."; return }
        val names = apps.map { packageManager.getApplicationLabel(it).toString() }
        AlertDialog.Builder(this).setTitle("اختر تطبيقاً مثبتاً").setItems(names.toTypedArray()) { _, which ->
            val app = apps[which]
            runAnalysis("تحليل ${names[which]}") { Analyzer.analyzeInstalledApk(this, app, search.text.toString()) }
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun runAnalysis(title: String, work: () -> AnalysisReport) {
        status.text = "$title: جارٍ الفحص..."; results.text = "يرجى الانتظار..."; setExportsEnabled(false)
        Thread {
            try {
                val report = work()
                runOnUiThread { lastReport = report; status.text = "اكتمل الفحص — ${report.entries} عنصر"; results.text = render(report); setExportsEnabled(true) }
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر إكمال الفحص"; results.text = e.message ?: "حدث خطأ غير معروف"; lastReport = null; setExportsEnabled(false) }
            }
        }.start()
    }

    private fun render(r: AnalysisReport): String = buildString {
        appendLine("SHADOW APK ANALYZER — تقرير الفحص")
        appendLine("════════════════════════════════")
        appendLine("المصدر: ${r.source}")
        appendLine("اسم الحزمة: ${r.metadata.packageName}")
        appendLine("الإصدار: ${r.metadata.versionName} (${r.metadata.versionCode})")
        appendLine("SHA-256: ${r.metadata.sha256}")
        appendLine("بصمة شهادة التوقيع: ${r.metadata.signerSha256.firstOrNull() ?: "غير متاحة"}")
        appendLine("الخطورة التقديرية: ${r.riskScore}/100 — ${r.riskLevel}")
        appendLine("الأذونات الحساسة: ${r.metadata.riskyPermissions.size}")
        r.metadata.riskyPermissions.forEach { appendLine("  ⚠ $it") }
        appendLine("SDK المستهدف: ${r.metadata.targetSdk ?: "غير معروف"} | الحد الأدنى: ${r.metadata.minSdk ?: "غير معروف"}")
        appendLine("الأذونات المطلوبة: ${r.metadata.permissions.size}")
        r.metadata.permissions.take(100).forEach { appendLine("  • $it") }
        appendLine("المكونات: ${r.metadata.components.size}")
        r.metadata.components.take(100).forEach { appendLine("  • $it") }
        appendLine("────────────────────────────────")
        appendLine("العناصر المفحوصة: ${r.entries} | الحجم المقروء: ${r.analyzedBytes / 1024} KB")
        appendLine("عدد المؤشرات: ${r.findings.size}")
        appendLine("مؤشرات مرتفعة: ${r.findings.count { it.severity == "مرتفع" }} | متوسطة: ${r.findings.count { it.severity == "متوسط" }}")
        appendLine("────────────────────────────────")
        if (r.findings.isEmpty()) appendLine("لم تُكتشف مؤشرات مطابقة لقائمة البحث.")
        r.findings.take(500).forEachIndexed { i, f ->
            appendLine("${i + 1}. [${f.severity}] ${f.term}")
            appendLine("الملف: ${f.file}")
            if (f.excerpt.isNotBlank()) appendLine(f.excerpt)
            appendLine("--------------------------------")
        }
        appendLine("ملاحظات وحدود التحليل:")
        r.notes.forEach { appendLine("• $it") }
    }

    private fun saveReport(uri: Uri, html: Boolean) {
        val report = lastReport ?: return
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { writer ->
                writer.write(if (html) Analyzer.toHtml(report) else Analyzer.toJson(report))
            } ?: error("تعذر إنشاء ملف التقرير")
            toast("تم حفظ التقرير بنجاح")
        } catch (e: Exception) { toast("فشل حفظ التقرير: ${e.message}") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
