package com.shadow.apkanalyzer

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipInputStream

 data class Finding(val file: String, val term: String, val excerpt: String, val severity: String)
 data class ApkMetadata(
    val packageName: String = "غير متاح", val versionName: String = "غير متاح",
    val versionCode: Long = 0, val minSdk: Int? = null, val targetSdk: Int? = null,
    val permissions: List<String> = emptyList(), val components: List<String> = emptyList(),
    val sha256: String = "غير متاح", val signerSha256: List<String> = emptyList(),
    val riskyPermissions: List<String> = emptyList()
 )
 data class AnalysisReport(
    val source: String, val entries: Int, val findings: List<Finding>, val notes: List<String>,
    val metadata: ApkMetadata = ApkMetadata(), val analyzedBytes: Long = 0,
    val riskScore: Int = 0, val riskLevel: String = "غير محدد"
 )

object Analyzer {
    private const val MAX_ENTRY_BYTES = 8 * 1024 * 1024
    private const val MAX_TOTAL_BYTES = 100L * 1024 * 1024
    private const val MAX_ENTRIES = 25000
    private const val MAX_ARCHIVE_BYTES = 250L * 1024 * 1024
    private val indicators = listOf(
        "com.android.billingclient", "BillingClient", "Purchase", "ProductDetails",
        "queryPurchasesAsync", "launchBillingFlow", "Subscription", "subscribe",
        "purchaseToken", "acknowledgePurchase", "GooglePlayBilling", "RevenueCat",
        "Purchases", "com.revenuecat", "stripe", "paypal", "in_app_purchase"
    )
    private val highRisk = listOf("DexClassLoader", "PathClassLoader", "Runtime.getRuntime", "exec(", "loadLibrary", "XposedBridge", "Frida", "AccessibilityService")
    private val riskyPermissionNames = listOf(
        "READ_SMS", "RECEIVE_SMS", "SEND_SMS", "READ_CALL_LOG", "WRITE_CALL_LOG",
        "RECORD_AUDIO", "CAMERA", "ACCESS_FINE_LOCATION", "ACCESS_BACKGROUND_LOCATION",
        "READ_CONTACTS", "WRITE_CONTACTS", "READ_PHONE_STATE", "REQUEST_INSTALL_PACKAGES",
        "SYSTEM_ALERT_WINDOW", "BIND_ACCESSIBILITY_SERVICE", "QUERY_ALL_PACKAGES"
    )

    fun installedLaunchableApps(context: Context): List<ApplicationInfo> {
        val pm = context.packageManager
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val resolved = if (Build.VERSION.SDK_INT >= 33) pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
            else pm.queryIntentActivities(intent, 0)
        return resolved.mapNotNull { it.activityInfo?.applicationInfo }.distinctBy { it.packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
    }

    fun analyzeUri(context: Context, uri: Uri, searchTerm: String = ""): AnalysisReport {
        val temp = File.createTempFile("shadow_scan_", ".apk", context.cacheDir)
        try {
            val input = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح الملف المحدد")
            input.use { stream ->
                temp.outputStream().buffered().use { out ->
                    val buffer = ByteArray(8192); var copied = 0L; var n: Int
                    while (stream.read(buffer).also { n = it } > 0) {
                        copied += n
                        if (copied > MAX_ARCHIVE_BYTES) error("حجم الملف يتجاوز الحد الآمن (250 MB)")
                        out.write(buffer, 0, n)
                    }
                }
            }
            if (temp.length() < 4) error("الملف فارغ أو غير صالح")
            temp.inputStream().use { input ->
                val signature = ByteArray(4); val count = input.read(signature)
                if (count < 4 || signature[0] != 0x50.toByte() || signature[1] != 0x4B.toByte()) error("صيغة غير مدعومة: اختر APK أو APKS أو XAPK صالحاً")
            }
            return analyzeFile(context, temp, uri.lastPathSegment ?: uri.toString(), searchTerm)
        } finally { temp.delete() }
    }

    fun analyzeInstalledApk(context: Context, app: ApplicationInfo, searchTerm: String = ""): AnalysisReport {
        val paths = listOfNotNull(app.sourceDir) + (app.splitSourceDirs?.toList() ?: emptyList())
        val reports = paths.distinct().map { path -> analyzeFile(context, File(path), "${app.packageName}: ${File(path).name}", searchTerm) }
        val first = reports.firstOrNull() ?: return AnalysisReport(app.packageName, 0, emptyList(), listOf("لا توجد ملفات APK متاحة للتحليل."))
        val combinedFindings = reports.flatMap { it.findings }.distinctBy { listOf(it.file, it.term, it.excerpt) }
        val score = calculateRisk(combinedFindings, first.metadata)
        return first.copy(
            source = app.packageName,
            entries = reports.sumOf { it.entries },
            findings = combinedFindings,
            notes = reports.flatMap { it.notes }.distinct() + if (paths.size > 1) listOf("تم فحص الحزمة الأساسية وملفات Split APK المتاحة.") else emptyList(),
            analyzedBytes = reports.sumOf { it.analyzedBytes }, riskScore = score, riskLevel = riskLabel(score)
        )
    }

    private fun analyzeFile(context: Context, file: File, source: String, searchTerm: String): AnalysisReport {
        require(file.isFile && file.length() <= MAX_ARCHIVE_BYTES) { "الملف غير موجود أو يتجاوز الحد الآمن (250 MB)" }
        file.inputStream().use { input ->
            val signature = ByteArray(4); val count = input.read(signature)
            require(count == 4 && signature[0] == 0x50.toByte() && signature[1] == 0x4B.toByte()) { "الملف ليس أرشيف APK/ZIP صالحاً" }
        }
        val findings = mutableListOf<Finding>()
        val notes = mutableListOf<String>()
        var entries = 0
        var total = 0L
        val terms = (indicators + highRisk + listOf(searchTerm).filter { it.isNotBlank() }).distinct()
        fun scan(input: InputStream, prefix: String, depth: Int) {
            if (depth > 2) return
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null && entries < MAX_ENTRIES && total < MAX_TOTAL_BYTES) {
                    entries++
                    if (!entry.isDirectory) {
                        val name = if (prefix.isEmpty()) entry.name else "$prefix/${entry.name}"
                        val lower = entry.name.lowercase()
                        val isNested = (lower.endsWith(".apk") || lower.endsWith(".apks") || lower.endsWith(".xapk")) && depth < 2
                        val interesting = lower.endsWith(".dex") || lower.endsWith(".xml") || lower.endsWith(".json") || lower.endsWith(".txt") || lower.endsWith(".properties") || lower.endsWith(".smali") || lower.endsWith(".arsc") || lower.endsWith(".so") || lower.endsWith(".odex") || lower.endsWith(".vdex")
                        if (isNested) {
                            val nested = readLimited(zip, 40 * 1024 * 1024)
                            total += nested.size
                            if (nested.isNotEmpty()) scan(ByteArrayInputStream(nested), name, depth + 1)
                        } else if (interesting) {
                            val bytes = readLimited(zip, MAX_ENTRY_BYTES)
                            total += bytes.size
                            val content = bytes.toString(Charsets.ISO_8859_1)
                            for (term in terms) {
                                var from = 0; var hits = 0
                                while (hits < 8) {
                                    val index = content.indexOf(term, from, ignoreCase = true)
                                    if (index < 0) break
                                    val start = (index - 90).coerceAtLeast(0)
                                    val end = (index + term.length + 140).coerceAtMost(content.length)
                                    val excerpt = content.substring(start, end).replace(Regex("[^\\x20-\\x7E\\r\\n]"), " ").trim()
                                    val severity = when {
                                        highRisk.any { it.equals(term, true) } -> "مرتفع"
                                        indicators.any { it.equals(term, true) } -> "متوسط"
                                        else -> "معلومة"
                                    }
                                    findings += Finding(name, term, excerpt, severity)
                                    from = index + term.length; hits++
                                }
                            }
                        } else {
                            val buffer = ByteArray(8192); var n: Int
                            while (zip.read(buffer).also { n = it } > 0) { total += n; if (total >= MAX_TOTAL_BYTES) break }
                        }
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
        }
        file.inputStream().use { scan(it, "", 0) }
        var metadata = readMetadata(context, file).copy(sha256 = sha256(file))
        if (metadata.packageName == "غير متاح") {
            val nestedApk = extractFirstNestedApk(context, file)
            if (nestedApk != null) {
                try { metadata = readMetadata(context, nestedApk).copy(sha256 = sha256(file)) } finally { nestedApk.delete() }
            }
        }
        val uniqueFindings = findings.distinctBy { listOf(it.file,it.term,it.excerpt) }
        val score = calculateRisk(uniqueFindings, metadata)
        notes += "المؤشرات النصية لا تثبت وحدها وجود سلوك ضار أو عملية شراء فعالة."
        notes += "قد تظهر نتائج إيجابية كاذبة بسبب مكتبات مضمّنة أو نصوص غير مستخدمة."
        notes += "ملفات DEX مفحوصة كسلاسل ثنائية؛ هذا ليس تفكيكاً كاملاً للتعليمات البرمجية."
        notes += "درجة الخطورة تقديرية وتعتمد على مؤشرات ثابتة وليست حكماً آلياً بوجود برمجية خبيثة."
        if (total >= MAX_TOTAL_BYTES || entries >= MAX_ENTRIES) notes += "توقف الفحص عند بلوغ حد الحماية من الملفات الضخمة."
        if (metadata.packageName == "غير متاح") notes += "تعذر استخراج بيانات Manifest بواسطة مدير الحزم في هذا الجهاز."
        return AnalysisReport(source, entries, uniqueFindings, notes, metadata, total, score, riskLabel(score))
    }

    private fun calculateRisk(findings: List<Finding>, metadata: ApkMetadata): Int {
        val high = findings.count { it.severity == "مرتفع" }.coerceAtMost(8)
        val medium = findings.count { it.severity == "متوسط" }.coerceAtMost(10)
        val permissions = metadata.riskyPermissions.size.coerceAtMost(10)
        return (high * 8 + medium * 2 + permissions * 3).coerceIn(0, 100)
    }

    private fun riskLabel(score: Int): String = when {
        score >= 60 -> "مرتفع"
        score >= 25 -> "متوسط"
        else -> "منخفض"
    }

    private fun sha256(file: File): String = try {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(16 * 1024); var n: Int
            while (input.read(buffer).also { n = it } > 0) digest.update(buffer, 0, n)
        }
        digest.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) { "تعذر الحساب" }

    private fun readLimited(input: InputStream, limit: Int): ByteArray {
        val out = ByteArrayOutputStream(); val buffer = ByteArray(8192); var total = 0; var n: Int
        while (input.read(buffer).also { n = it } > 0) {
            val take = minOf(n, limit - total); if (take > 0) out.write(buffer, 0, take)
            total += n; if (total >= limit) break
        }
        return out.toByteArray()
    }

    private fun extractFirstNestedApk(context: Context, archive: File): File? {
        return try {
            ZipInputStream(archive.inputStream().buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.lowercase().endsWith(".apk")) {
                        val temp = File.createTempFile("shadow_nested_", ".apk", context.cacheDir)
                        try {
                            temp.outputStream().use { out ->
                                val buffer = ByteArray(8192); var total = 0L; var n: Int
                                while (zip.read(buffer).also { n = it } > 0) {
                                    total += n
                                    if (total > MAX_TOTAL_BYTES) error("حجم APK فرعي يتجاوز الحد المسموح")
                                    out.write(buffer, 0, n)
                                }
                            }
                            return temp
                        } catch (e: Exception) { temp.delete(); throw e }
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
                null
            }
        } catch (_: Exception) { null }
    }

    @Suppress("DEPRECATION")
    private fun readMetadata(context: Context, file: File): ApkMetadata {
        return try {
            val pm = context.packageManager
            val baseFlags = PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS
            val flags = baseFlags or (if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else 0)
            val info: PackageInfo = if (Build.VERSION.SDK_INT >= 33) pm.getPackageArchiveInfo(file.absolutePath, PackageManager.PackageInfoFlags.of(flags.toLong()))
                ?: return ApkMetadata() else pm.getPackageArchiveInfo(file.absolutePath, flags) ?: return ApkMetadata()
            val app = info.applicationInfo
            val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
            val permissions = info.requestedPermissions?.toList() ?: emptyList()
            val risky = permissions.filter { permission -> riskyPermissionNames.any { permission.endsWith(".$it") || permission.endsWith(it) } }
            val signers = try {
                if (Build.VERSION.SDK_INT >= 28) {
                    val signing = info.signingInfo
                    val certs = if (signing.hasMultipleSigners()) signing.apkContentsSigners else signing.signingCertificateHistory
                    certs.map { cert -> MessageDigest.getInstance("SHA-256").digest(cert.toByteArray()).joinToString("") { "%02x".format(it) } }
                } else emptyList()
            } catch (_: Exception) { emptyList() }
            ApkMetadata(info.packageName ?: "غير متاح", info.versionName ?: "غير متاح", code,
                if (Build.VERSION.SDK_INT >= 24) app?.minSdkVersion else null,
                if (Build.VERSION.SDK_INT >= 24) app?.targetSdkVersion else null,
                permissions, buildList {
                    info.activities?.forEach { add("Activity: ${it.name}") }
                    info.services?.forEach { add("Service: ${it.name}") }
                    info.receivers?.forEach { add("Receiver: ${it.name}") }
                    info.providers?.forEach { add("Provider: ${it.name}") }
                }, signerSha256 = signers, riskyPermissions = risky)
        } catch (_: Exception) { ApkMetadata() }
    }

    fun toJson(r: AnalysisReport): String {
        fun q(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\""
        return buildString {
            append("{\n  \"source\": ${q(r.source)},\n  \"entries\": ${r.entries},\n  \"analyzedBytes\": ${r.analyzedBytes},\n  \"riskScore\": ${r.riskScore},\n  \"riskLevel\": ${q(r.riskLevel)},\n")
            append("  \"metadata\": {\"package\": ${q(r.metadata.packageName)}, \"version\": ${q(r.metadata.versionName)}, \"versionCode\": ${r.metadata.versionCode}, \"sha256\": ${q(r.metadata.sha256)}, \"signerSha256\": [${r.metadata.signerSha256.joinToString(",") { q(it) }}], \"permissions\": [${r.metadata.permissions.joinToString(",") { q(it) }}], \"riskyPermissions\": [${r.metadata.riskyPermissions.joinToString(",") { q(it) }}]},\n")
            append("  \"findings\": [\n")
            append(r.findings.joinToString(",\n") { "    {\"file\": ${q(it.file)}, \"term\": ${q(it.term)}, \"severity\": ${q(it.severity)}, \"excerpt\": ${q(it.excerpt)}}" })
            append("\n  ],\n  \"notes\": [${r.notes.joinToString(",") { q(it) }}]\n}\n")
        }
    }

    fun toHtml(r: AnalysisReport): String {
        fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
        return """<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Shadow Scan Report</title><style>body{font-family:Arial;background:#101018;color:#eee;padding:22px}h1{color:#c4b5fd}section{background:#1d1b2a;padding:14px;margin:12px 0;border-radius:12px}.risk{color:#fca5a5}pre{white-space:pre-wrap;overflow-wrap:anywhere}</style><h1>SHADOW APK ANALYZER</h1><section><h2>ملخص الفحص</h2><p>المصدر: ${esc(r.source)}</p><p>الحزمة: ${esc(r.metadata.packageName)}</p><p>الإصدار: ${esc(r.metadata.versionName)}</p><p>SHA-256: ${esc(r.metadata.sha256)}</p><p>الخطورة التقديرية: ${r.riskScore}/100 — ${esc(r.riskLevel)}</p><p>العناصر: ${r.entries} — النتائج: ${r.findings.size}</p><p>الأذونات الحساسة: ${r.metadata.riskyPermissions.joinToString(", ") { esc(it) }}</p></section><h2>النتائج</h2>${r.findings.joinToString("") { "<section><b class='risk'>${esc(it.severity)}</b><h3>${esc(it.term)}</h3><p>${esc(it.file)}</p><pre>${esc(it.excerpt)}</pre></section>" }}<section><h2>ملاحظات</h2>${r.notes.joinToString("<p>") { esc(it) }}</section></html>"""
    }
}
